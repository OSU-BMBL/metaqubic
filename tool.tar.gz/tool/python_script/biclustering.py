import os
import sys


# set and check arguments
tool_path = sys.argv[1]
if (os.path.exists(tool_path) == False):
    print "The path of tools is invalid: " + tool_path
    sys.exit()
matrix_path = sys.argv[2]
if (os.path.exists(matrix_path) == False):
    print "The path of matrix is invalid: " + matrix_path
    sys.exit()
output_path = sys.argv[3]
if (os.path.isdir(output_path)) == False):
    print "The path of output directory is invalid: " + output_path
    sys.exit()

argument = ""
count = 0
while count < len(sys.argv):
    if sys.argv[count] == '-f':
        argument = argument + sys.argv[count] + " " + sys.argv[count + 1] + " "
        f = float(sys.argv[count + 1])
    if sys.argv[count] == '-c':
        argument = argument + sys.argv[count] + " " + sys.argv[count + 1] + " "
        c = float(sys.argv[count + 1])
    if sys.argv[count] == '-o':
        argument = argument + sys.argv[count] + " " + sys.argv[count + 1] + " "
        o = int(sys.argv[count + 1])
    if sys.argv[count] == '-k':
        argument = argument + sys.argv[count] + " " + sys.argv[count + 1] + " "
        k = int(sys.argv[count + 1])
    count = count + 1

# run qubic for biclustering
qubic_execute = tool_path + "/qubic/qubic -i "
os.system(qubic_execute + matrix_path + argument)
os.system("mv " + tool_path + "/qubic/" + os.path.basename(matrix_path) + ".blocks " + output_path)

# ouptut genes and samples lists
os.system("cd " + output_path + " for file in *blocks; do grep Conds $file |cut -d \':\' -f2 >\"condition.txt\"; done")
os.system("cd " + output_path + " for file in *blocks; do grep Genes $file |cut -d \':\' -f2 >\"gene.txt\"; done\")
