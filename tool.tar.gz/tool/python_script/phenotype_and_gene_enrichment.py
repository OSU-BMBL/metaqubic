import os
import sys
import copy
import scipy.stats as stats

# define function
def get_Pvalue(x1, x2, x3, x4):
    value = stats.hypergeom.sf(int(x4) - 1, int(x1), int(x2), int(x3))
    return value

# chcek argument

# get lists from the blocks
blocks_gene_list = sys.argv[1]
if os.path.exists(blocks_gene_list) == False:
    print "ERROR - The path of bicluster matrix for gene is invalid: " + blocks_gene_list
    sys.exit()
blocks_gene_list_file = open(blocks_gene_list)
blocks_gene_list_data = blocks_gene_list_file.readlines()

# get lists from enrichments lists
gene_list = sys.argv[2]
if os.path.exists(gene_list) == False:
    print "ERROR - The path of gene annotation matrix is invalid: " + gene_list
    sys.exit()
gene_list_file = open(gene_list)
gene_list_data = gene_list_file.readlines()

# get lists from the blocks
blocks_sample_list = sys.argv[3]
if os.path.exists(blocks_sample_list) == False:
    print "ERROR - The path of bicluster matrix for gene is invalid: " + blocks_sample_list
    sys.exit()
blocks_sample_list_file = open(blocks_sample_list)
blocks_sample_list_data = blocks_sample_list_file.readlines()

# get lists from enrichments lists
sample_list = sys.argv[4]
if os.path.exists(sample_list) == False:
    print "ERROR - The path of gene annotation matrix is invalid: " + sample_list
    sys.exit()
sample_list_file = open(genesample_list_list)
sample_list_data = sample_list_file.readlines()

output_path = sys.argv[5]
if os.path.exists(output_path) == False:
    print "ERROR - The path of output directory is invalid: " + output_path
    sys.exit()