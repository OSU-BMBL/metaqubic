import os
import sys

# check arguments
DNA_matrix = sys.argv[1]
if os.path.exists(DNA_matrix) == False:
    print "ERROR - The path of DNA matrix is invalid: " + DNA_matrix
    sys.exit()
RNA_matrix = sys.argv[2]
if os.path.exists(RNA_matrix) == False:
    print "ERROR - The path of RNA matrix is invalid: " + RNA_matrix
    sys.exit()
RNA_DNA_matrix = sys.argv[3]
if os.path.exists(RNA_DNA_matrix) == False:
    print "ERROR - The path of RNA/DNA matrix is invalid: " + RNA_DNA_matrix
    sys.exit()
catalog_path = sys.argv[4]
if os.path.exists(catalog_path) == False:
    print "ERROR - The path of catalog directory is invalid: " + catalog_path
    sys.exit()
output_path = sys.argv[5]
if os.path.isdir(output_path) == False:
    print "ERROR - The path of output directory is invalid: " + RNA_DNA_matrix
    sys.exit()

# check if the file under catalog directory is valid
fileNames = os.listdir(catalog_path)
if len(fileNames) == 0: # if no file under the folder
    print "ERROR - Catalog directory is empty: " + catalog_path
    sys.exit()

for fileName in fileNames: # report error format catalog files
    catalog_file = open(catalog_path + "/" + fileName)
    oneLine = catalog_file.readline()
    if(len(oneLine.split()) != 15):
        print "ERROR - the format of this file is invalid: " + catalog_path + "/" + fileName + ", the number of column should be 15."
        sys.exit()

# now the catalog file should be valid, start merge to the matrices

# **************************************************************************************************************************
# DNA matrix merge
# intialize annotation table 
DNA_matrix_file = open(DNA_matrix)
DNA_matrix_data = DNA_matrix_file.readlines()
first_row_key = DNA_matrix_data[0].split()[0] # the key in the dictionary lead to the first line of DNA matrix
DNA_dictionary = {}

# hash annotation table
for line in DNA_matrix_data:
    DNA_dictionary[line.split()[0]] = line[:-1]

# merge data to the dictionary
fileNames = os.listdir(catalog_path)
fileNames = sorted(fileNames)
for fileName in fileNames: # read each and merge to the dictionary
    catalog_file = open(catalog_path + "/" + fileName)
    DNA_dictionary[first_row_key] = DNA_dictionary[first_row_key] + "\t" + fileName[:-21] # add column to the first row of DNA matrix
    data = catalog_file.readlines()

    # read catalog line by line
    for line in data: 
        key = line.split()[0]
        if key in DNA_dictionary: # if gene can be found in the DNA matrix
            DNA_dictionary[key] = DNA_dictionary[key] + "\t" + line.split()[3] 
        else: # if gene can't be found, add new row regard this gene
            zero_string = "0\t" * len(DNA_dictionary[first_row_key].split()) - 2
            DNA_dictionary[key] = key + "\t" + zero_string + line.split()[3]
    
    # add 0 to the gene which is not mapped in this sample
    for key in DNA_dictionary:
        if len(DNA_dictionary[key].split()) != len(DNA_dictionary[first_row_key].split()):
            DNA_dictionary[key] = DNA_dictionary[key] + "\t0\t"

# output updated DNA matrix
DNA_outFile = open(output_path + "/updated_DNA_matrix.txt", "w")
for line in DNA_matrix_data:
    DNA_outFile.write(DNA_dictionary[line.split()[0]] + '\n')

# **************************************************************************************************************************
# RNA matrix merge
# intialize annotation table 
RNA_matrix_file = open(RNA_matrix)
RNA_matrix_data = RNA_matrix_file.readlines()
first_row_key = RNA_matrix_data[0].split()[0] # the key in the dictionary lead to the first line of RNA matrix
RNA_dictionary = {}

# hash annotation table
for line in RNA_matrix_data:
    RNA_dictionary[line.split()[0]] = line[:-1]

# merge data to the dictionary
fileNames = os.listdir(catalog_path)
fileNames = sorted(fileNames)
for fileName in fileNames: # read each and merge to the dictionary
    catalog_file = open(catalog_path + "/" + fileName)
    RNA_dictionary[first_row_key] = RNA_dictionary[first_row_key] + "\t" + fileName[:-21] # add column to the first row of RNA matrix
    data = catalog_file.readlines()

    # read catalog line by line
    for line in data: 
        key = line.split()[0]
        if key in RNA_dictionary: # if gene can be found in the RNA matrix
            RNA_dictionary[key] = RNA_dictionary[key] + "\t" + line.split()[6] 
        else: # if gene can't be found, add new row regard this gene
            zero_string = "0\t" * len(RNA_dictionary[first_row_key].split()) - 2
            RNA_dictionary[key] = key + "\t" + zero_string + line.split()[6]
    
    # add 0 to the gene which is not mapped in this sample
    for key in RNA_dictionary:
        if len(RNA_dictionary[key].split()) != len(RNA_dictionary[first_row_key].split()):
            RNA_dictionary[key] = RNA_dictionary[key] + "\t0\t"

# output updated RNA matrix
RNA_outFile = open(output_path + "/updated_RNA_matrix.txt", "w")
for line in RNA_matrix_data:
    RNA_outFile.write(RNA_dictionary[line.split()[0]] + '\n')

# **************************************************************************************************************************
# RNA/DNA matrix merge
# intialize annotation table 
RNA_DNA_matrix_file = open(RNA_DNA_matrix)
RNA_DNA_matrix_data = RNA_DNA_matrix_file.readlines()
first_row_key = RNA_DNA_matrix_data[0].split()[0] # the key in the dictionary lead to the first line of RNA/DNA matrix
RNA_DNA_dictionary = {}

# hash annotation table
for line in RNA_DNA_matrix_data:
    RNA_DNA_dictionary[line.split()[0]] = line[:-1]

# merge data to the dictionary
fileNames = os.listdir(catalog_path)
fileNames = sorted(fileNames)
for fileName in fileNames: # read each and merge to the dictionary
    catalog_file = open(catalog_path + "/" + fileName)
    RNA_DNA_dictionary[first_row_key] = RNA_DNA_dictionary[first_row_key] + "\t" + fileName[:-21] # add column to the first row of RNA/DNA matrix
    data = catalog_file.readlines()

    # read catalog line by line
    for line in data: 
        key = line.split()[0]
        if key in RNA_DNA_dictionary: # if gene can be found in the RNA/DNA matrix
            RNA_DNA_dictionary[key] = RNA_DNA_dictionary[key] + "\t" + line.split()[9] 
        else: # if gene can't be found, add new row regard this gene
            zero_string = "0\t" * len(RNA_DNA_dictionary[first_row_key].split()) - 2
            RNA_DNA_dictionary[key] = key + "\t" + zero_string + line.split()[9]
    
    # add 0 to the gene which is not mapped in this sample
    for key in RNA_DNA_dictionary:
        if len(RNA_DNA_dictionary[key].split()) != len(RNA_DNA_dictionary[first_row_key].split()):
            RNA_DNA_dictionary[key] = RNA_DNA_dictionary[key] + "\t0\t"

# output updated RNA matrix
RNA_DNA_outFile = open(output_path + "/updated_RNA_DNA_matrix.txt", "w")
for line in RNA_DNA_matrix_data:
    RNA_DNA_outFile.write(RNA_DNA_dictionary[line.split()[0]] + '\n')
