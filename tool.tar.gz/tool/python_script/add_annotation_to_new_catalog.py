import os
import sys

# check arguments
IGC_annotation_table = sys.argv[1]
if os.path.exists(IGC_annotation_table) == False:
    print "ERROR - The path of annotation table is invalid: " + IGC_annotation_table
    sys.exit()
output_path = sys.argv[2]
if os.path.exists(output_path) == False:
    print "ERROR - The path of output path is invalid: " + output_path
    sys.exit()
catalog_name = "metagenome_metatranscriptome_integrative_coverage"

# *****************************************************************************************
# fetch catalog file from "alignment_result" folder and put it under "catalog" folder
# *****************************************************************************************
alignment_result = output_path + "/" + "alignment_result/"
if os.path.exists(alignment_result) == False:
    print "ERROR - can't find floder \"alignment_result\" under the output path: " + output_path
    sys.exit()
fileNames = os.listdir(alignment_result)

# create new catalog file
catalog_folder = output_path + "/" + "catalog/"
os.system("mkdir " + catalog_folder)
for fileName in fileNames:
    if os.path.exists(alignment_result + fileName + "/" + catalog_name) == True:
        os.system("mv " + alignment_result + fileName + "/" + catalog_name + " " + catalog_folder + fileName + ".integrative.coverage")
    else:
        print "dataset: " + fileName + " doesn't get gene mapping result successfully"



# at this moment we don't need to add annotation to the catalog

# # *****************************************************************************************
# # add annotation to new catalog
# # *****************************************************************************************

# # intialize annotation table 
# IGC_annotation_file = open(IGC_annotation_table)
# IGC_annotation = IGC_annotation_file.readlines()
# dictionary = {}

# # hash annotation table
# for line in IGC_annotation:
#     dictionary[line.split('\t')[1]] = line[:-1]

# # get new catalogs
# catalog_735 = os.listdir(catalog_folder)
# for fileName in catalog_735:
#     catalog = open(catalog_folder + "/" + fileName)
#     data = catalog.readlines()

#     outFile = open(catalog_folder + "/" + fileName, "w")
#     for line in data:
#         outFile.write(line[:-1] + "\t" + str(dictionary[line.split('\t')[0]].split('\t')[7]) + "\t" + str(dictionary[line.split('\t')[0]].split('\t')[11]) + "\t" + str(dictionary[line.split('\t')[0]].split('\t')[5]) + "\t" + str(dictionary[line.split('\t')[0]].split('\t')[6]) + '\n')

