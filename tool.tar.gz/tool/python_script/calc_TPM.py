import os
import sys
import copy

# check parameters
IGC_annotation_table = sys.argv[1]
if (os.path.exists(IGC_annotation_table) == False):
    print "The path of IGC annotation table is invalid: " + IGC_annotation_table
    sys.exit()
DNA_matrix = sys.argv[2]
if (os.path.exists(DNA_matrix) == False):
    print "The path of DNA matrix is invalid: " + DNA_matrix
    sys.exit()
RNA_matrix = sys.argv[3]
if (os.path.exists(RNA_matrix) == False):
    print "The path of RNA matrix is invalid: " + RNA_matrix
    sys.exit()
RNA_DNA_matrix = sys.argv[4]
if (os.path.exists(RNA_DNA_matrix) == False):
    print "The path of RNA/DNA matrix is invalid: " + RNA_DNA_matrix
    sys.exit()
output_path = sys.argv[5]
if (os.path.isdir(output_path) == False):
    print "The path of output directory is invalid: " + output_path
    sys.exit()
if len(sys.argv[6]) > 0:
    if sys.argv[6].isdigit() == False:
        print "The TPM cut-off value is invalid: " + sys.argv[6] + ", should be a number"
        sys.exit()
    elif int(sys.argv[6]) < 0:
        print "The TPM cut-off value is invalid: " + sys.argv[6] + ", should be greater than 0"
        sys.exit()
    else:
        cut_off_value = int(sys.argv[6])
    
# return true if at least one element greater than cut off value
# return false if all element less than cut off value
def keep_this_line(aList):
    for element in aList:
        if float(element) > cut_off_value:
            return True
    return False


# intialize annotation table 
IGC_annotation_file = open(IGC_annotation_table)
IGC_annotation = IGC_annotation_file.readlines()
dictionary = {}

# hash annotation table
for line in IGC_annotation:
    dictionary[line.split('\t')[1]] = line[:-1]

# ***************************************************************************************************************
# start processing DNA matrix:
# ***************************************************************************************************************
DNA_matrix_file = open(DNA_matrix)
DNA_matrix_data = DNA_matrix_file.readlines()
DNA_matrix_data_original = copy.deepcopy(DNA_matrix_data)
row = 0
column = 0

# convert DNA_matrix_data to the matrix
while row < len(DNA_matrix_data):
    DNA_matrix_data[row] = DNA_matrix_data[row].split('\t')
    row = row + 1

# start calculating TPM
row = 1
column = 1
# step 1 divide read counts by gene length in kilobase
while row < len(DNA_matrix_data):
    while column < len(DNA_matrix_data[0]):
        gene_name = DNA_matrix_data[row][0]
        gene_length = int(dictionary[gene_name].split('\t')[2])
        DNA_matrix_data[row][column] = str( float( DNA_matrix_data[row][column] ) /  ( float(gene_length) / 1000) )

        column = column + 1
    row = row + 1

# step 2 Count up all the RPK values in a sample and divide this number by 1,000,000
scaling_factor = []
scaling_factor.append(0)
row = 1
column = 1
while column < len(DNA_matrix_data[0]):
    total = 0.0
    while row < len(DNA_matrix_data):
        total = total + float(DNA_matrix_data[row][column])

        row = row + 1

    scaling_factor.append(total / 1000000)
    column = column + 1

# step 3
row = 1
column = 1
while column < len(DNA_matrix_data[0]):
    while row < len(DNA_matrix_data):
        DNA_matrix_data[row][column] = str( float( DNA_matrix_data[row][column] ) / scaling_factor[column] )

        row = row + 1
    column = column + 1

count = 0
for line in DNA_matrix_data[1:]:
    if keep_this_line(line[1:]) == True:
        count = count + 1
    
# write to the file
DNA_matrix_outFile = open(output_path + "/TPM-filtered_DNA_matrix", "w")
DNA_matrix_outFile.write(DNA_matrix_data_original[0])
count = 1
while count < len(DNA_matrix_data_original):
    if keep_this_line(DNA_matrix_data[count][1:]) == True:
        DNA_matrix_outFile.write(DNA_matrix_data_original[count])

    count = count + 1

DNA_matrix_file.close()
DNA_matrix_outFile.close()
# ***************************************************************************************************************
# start processing RNA matrix:
# ***************************************************************************************************************
DNA_matrix_file = open(RNA_matrix)
DNA_matrix_data = DNA_matrix_file.readlines()
DNA_matrix_data_original = copy.deepcopy(DNA_matrix_data)
row = 0
column = 0

# convert DNA_matrix_data to the matrix
while row < len(DNA_matrix_data):
    DNA_matrix_data[row] = DNA_matrix_data[row].split('\t')
    row = row + 1

# start calculating TPM
row = 1
column = 1
# step 1 divide read counts by gene length in kilobase
while row < len(DNA_matrix_data):
    while column < len(DNA_matrix_data[0]):
        gene_name = DNA_matrix_data[row][0]
        gene_length = int(dictionary[gene_name].split('\t')[2])
        DNA_matrix_data[row][column] = str( float( DNA_matrix_data[row][column] ) /  ( float(gene_length) / 1000) )

        column = column + 1
    row = row + 1

# step 2 Count up all the RPK values in a sample and divide this number by 1,000,000
scaling_factor = []
scaling_factor.append(0)
row = 1
column = 1
while column < len(DNA_matrix_data[0]):
    total = 0.0
    while row < len(DNA_matrix_data):
        total = total + float(DNA_matrix_data[row][column])

        row = row + 1

    scaling_factor.append(total / 1000000)
    column = column + 1

# step 3
row = 1
column = 1
while column < len(DNA_matrix_data[0]):
    while row < len(DNA_matrix_data):
        DNA_matrix_data[row][column] = str( float( DNA_matrix_data[row][column] ) / scaling_factor[column] )

        row = row + 1
    column = column + 1

count = 0
for line in DNA_matrix_data[1:]:
    if keep_this_line(line[1:]) == True:
        count = count + 1
    
# write to the file
DNA_matrix_outFile = open(output_path + "/TPM-filtered_RNA_matrix", "w")
DNA_matrix_outFile.write(DNA_matrix_data_original[0])
count = 1
while count < len(DNA_matrix_data_original):
    if keep_this_line(DNA_matrix_data[count][1:]) == True:
        DNA_matrix_outFile.write(DNA_matrix_data_original[count])

    count = count + 1

DNA_matrix_file.close()
DNA_matrix_outFile.close()

# ***************************************************************************************************************
# start looking for mutual gene list:
# ***************************************************************************************************************
TPM_DNA_matrix = open(output_path + "/TPM-filtered_DNA_matrix")
TPM_RNA_matrix = open(output_path + "/TPM-filtered_RNA_matrix")
TPM_DNA_matrix_data = TPM_DNA_matrix.readlines()
TPM_RNA_matrix_data = TPM_RNA_matrix.readlines()

# get DNA gene list
DNA_gene_list = []
for line in TPM_DNA_matrix_data[1:]:
    DNA_gene_list.append(line.split('\t')[0])

# get RNA gene list
RNA_gene_list = []
for line in TPM_RNA_matrix_data[1:]:
    RNA_gene_list.append(line.split('\t')[0])

# output mutual gene list
mutual_gene_list = set(DNA_gene_list).intersection(RNA_gene_list)
mutual_gene_list_outFile = open(output_path + "/mutual_gene_list", "w")
mutual_gene_dictionary = {}
for element in mutual_gene_list:
    mutual_gene_dictionary[element] = element
    mutual_gene_list_outFile.write(element + '\n')

# output filtered RNA/DNA matrix
RNA_DNA_matrix_file = open(RNA_DNA_matrix)
RNA_DNA_matrix_data = RNA_DNA_matrix_file.readlines()
RNA_DNA_matrix_outFile = open(output_path + "/TPM-filtered_RNA_DNA_matrix", "w")
for line in RNA_DNA_matrix_data[1:]:
    if line.split('\t')[0] in mutual_gene_dictionary:
        RNA_DNA_matrix_outFile.write(line)

