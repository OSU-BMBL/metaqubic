import os
import sys
import copy
# import scipy.stats as stats

# check arguments
IGC_annotation_table = sys.argv[1]
if os.path.exists(IGC_annotation_table) == False:
    print "ERROR - The path of annotation table is invalid: " + IGC_annotation_table
    sys.exit()

output_path = sys.argv[2]
if os.path.isdir(output_path) == False:
    print "ERROR - The path of output directory is invalid: " + output_path
    sys.exit()

column_list = []
count = 3
while count < len(sys.argv):
    if sys.argv[count].isdigit() == True and sys.argv[count].find("-") == -1 and sys.argv[count].find(".") == -1:
        column_list.append(int(sys.argv[count]))
    else:
        print "ERROR - The column number should be positive integer: " + sys.argv[count]
        sys.exit()
    count = count + 1


# start processing

# read annotation table
IGC_annotation_file = open(IGC_annotation_table)
IGC_annotation_data = IGC_annotation_file.readlines()
count = 0
while count < len(IGC_annotation_data):
    IGC_annotation_data[count] = IGC_annotation_data[count][:-1]
    count = count + 1

for column in column_list:
    outFile = open(output_path + "/column_" + str(column) + ".txt", "w")
    for line in IGC_annotation_data:
        outFile.write(line.split('\t')[1] + "\t" + line.split('\t')[column - 1] + "\n")
    

