import os
import sys
import copy
import scipy.stats as stats

# define function
def get_Pvalue(x1, x2, x3, x4):
    value = stats.hypergeom.sf(int(x4) - 1, int(x1), int(x2), int(x3))
    return value


# chcek argument

# get lists from the blocks
blocks_list = sys.argv[1]
if os.path.exists(blocks_list) == False:
    print "ERROR - The path of bicluster matrix is invalid: " + blocks_list
    sys.exit()
blocks_list_file = open(blocks_list)
blocks_list_data = blocks_list_file.readlines()

# get lists from enrichments lists
gene_list = sys.argv[2]
if os.path.exists(gene_list) == False:
    print "ERROR - The path of gene annotation matrix is invalid: " + gene_list
    sys.exit()
gene_list_file = open(gene_list)
gene_list_data = gene_list_file.readlines()

output_path = sys.argv[3]
if os.path.exists(output_path) == False:
    print "ERROR - The path of output directory is invalid: " + output_path
    sys.exit()
# convert it to a matrix
count = 0
while count < len(gene_list_data):
    gene_list_data[count] = [gene_list_data[count].split()[0], gene_list_data[count].split()[1]]
    count = count + 1

gene_list_data = sorted(gene_list_data, key=lambda gene_list_data : gene_list_data[1])

# classification
count = 0
dictionary = {}
while count < len(gene_list_data):
    dictionary[gene_list_data[count][1]] = []
    count = count + 1

count = 0
while count < len(gene_list_data):
    dictionary[gene_list_data[count][1]].append(gene_list_data[count][0])
    count = count + 1

# start getting Pvalue
cluster = []
count = 0
for line in blocks_list_data:
    cluster.append([])
    aList = line.split()
    temp = {}
    bList = []
    for key in dictionary:
        x1 = len(aList) + len(dictionary[key])
        x2 = len(aList)
        x3 = len(dictionary[key])
        x4 = len(set(aList).intersection(dictionary[key]))
        pValue = get_Pvalue(x1, x2, x3, x4)
        temp[key] = pValue
        bList.append(pValue)
    minimum = min(bList)
    cluster[count].append([])
    cluster[count].append(minimum)
    for key in temp:
        if temp[key] == minimum:
            cluster[count][0].append(key)
    count = count + 1

# extract useful information

aDictionary = {}
for key in dictionary:
    aDictionary[key] = []


count = 0
for key in dictionary:
    for label in cluster[count][0]:
        aDictionary[label].append(count)
        count = count + 1

# write out the file
outFile = open(output_path + "/report", "w")
for key in aDictionary:
    if len(aDictionary[key]) > 0:
        outFile.write("\nFunction: " + key + '\n')
        for bicluster in aDictionary[key]:
            outFile.write("BC" + str(bicluster) + ":\t" + blocks_list_data[bicluster])
            outFile.write("P-value: " + "\t" + str(cluster[bicluster][1]) + "\n")
    else:
        outFile.write("\nFunction: " + key + '\nN/A\n\n')



        

    


